document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('feedbackForm');
    const successMessage = document.getElementById('successMessage');
    const submitBtn = form.querySelector('.submit-btn');
    const btnText = submitBtn.querySelector('.btn-text');
    const btnLoader = submitBtn.querySelector('.btn-loader');

    // Form validation
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateForm()) {
            submitForm();
        }
    });

    // Real-time validation
    const inputs = form.querySelectorAll('input, textarea');
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        input.addEventListener('input', function() {
            clearError(this);
        });
    });

    function validateForm() {
        let isValid = true;
        const fields = [
            { id: 'name', validator: validateName },
            { id: 'email', validator: validateEmail },
            { id: 'message', validator: validateMessage }
        ];

        fields.forEach(field => {
            const input = document.getElementById(field.id);
            if (!field.validator(input.value)) {
                showError(input, getErrorMessage(field.id));
                isValid = false;
            }
        });

        return isValid;
    }

    function validateField(field) {
        const value = field.value.trim();
        let isValid = true;
        let errorMessage = '';

        switch (field.id) {
            case 'name':
                isValid = validateName(value);
                errorMessage = getErrorMessage('name');
                break;
            case 'email':
                isValid = validateEmail(value);
                errorMessage = getErrorMessage('email');
                break;
            case 'message':
                isValid = validateMessage(value);
                errorMessage = getErrorMessage('message');
                break;
        }

        if (!isValid && value !== '') {
            showError(field, errorMessage);
        } else {
            clearError(field);
        }
    }

    function validateName(name) {
        return name.trim().length >= 2;
    }

    function validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    function validateMessage(message) {
        return message.trim().length >= 10;
    }

    function getErrorMessage(fieldId) {
        const messages = {
            name: 'Please enter a valid name (at least 2 characters)',
            email: 'Please enter a valid email address',
            message: 'Please enter a message (at least 10 characters)'
        };
        return messages[fieldId];
    }

    function showError(field, message) {
        const errorElement = document.getElementById(field.id + 'Error');
        errorElement.textContent = message;
        field.style.borderColor = '#ef4444';
    }

    function clearError(field) {
        const errorElement = document.getElementById(field.id + 'Error');
        errorElement.textContent = '';
        field.style.borderColor = '#e5e7eb';
    }

    function submitForm() {
        // Show loading state
        submitBtn.disabled = true;
        submitBtn.classList.add('loading');
        btnText.style.opacity = '0';
        btnLoader.style.display = 'block';

        // Simulate API call
        setTimeout(() => {
            // Hide form and show success message
            form.style.display = 'none';
            successMessage.style.display = 'block';
            
            // Reset button state
            submitBtn.disabled = false;
            submitBtn.classList.remove('loading');
            btnText.style.opacity = '1';
            btnLoader.style.display = 'none';
        }, 2000);
    }
});

// Function to reset the form (called from HTML)
function resetForm() {
    const form = document.getElementById('feedbackForm');
    const successMessage = document.getElementById('successMessage');
    
    // Reset form
    form.reset();
    form.style.display = 'block';
    successMessage.style.display = 'none';
    
    // Clear all errors
    const errorMessages = document.querySelectorAll('.error-message');
    errorMessages.forEach(error => {
        error.textContent = '';
    });
    
    const inputs = form.querySelectorAll('input, textarea');
    inputs.forEach(input => {
        input.style.borderColor = '#e5e7eb';
    });
}